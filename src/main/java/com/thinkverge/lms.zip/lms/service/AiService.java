import org.springframework.ai.chat.client.ChatClient;
import org.springframework.stereotype.Service;

@Service
public class AiService {

    private final ChatClient chatClient;

    public AiService(ChatClient.Builder builder) {
        this.chatClient = builder.build();
    }

    public String getAiReply(String courseTitle, String message) {

        String prompt = """
        You are a helpful AI teaching assistant for course: %s.
        Answer clearly and concisely.

        User question:
        %s
        """.formatted(courseTitle, message);

        return chatClient.prompt()
                .user(prompt)
                .call()
                .content();
    }
}